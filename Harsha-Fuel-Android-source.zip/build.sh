#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${FUEL_ANDROID_JAR:=$PWD/sdk/android-35/android.jar}"
: "${FUEL_BUILD_TOOLS:=$PWD/sdk/android-15}"
: "${FUEL_ECJ_JAR:=$PWD/sdk/ecj-3.38.0.jar}"
: "${FUEL_SIGNING_KEY:=$PWD/keys/harsha-fuel-signing.p12}"
: "${FUEL_SIGNING_PASSWORD_FILE:=$PWD/keys/store-password.txt}"
: "${FUEL_APK_OUTPUT:=$PWD/../Harsha-Fuel-1.0.apk}"
mkdir -p out gen classes
"$FUEL_BUILD_TOOLS/aapt2" compile --dir res -o out/resources.zip
"$FUEL_BUILD_TOOLS/aapt2" link -I "$FUEL_ANDROID_JAR" --manifest AndroidManifest.xml --java gen -o out/unsigned.apk out/resources.zip
java -jar "$FUEL_ECJ_JAR" -source 8 -target 8 -bootclasspath "$FUEL_ANDROID_JAR" -d classes src/com/harsha/fuel/MainActivity.java
mapfile -t class_files < <(find classes -name '*.class' -type f | sort)
"$FUEL_BUILD_TOOLS/d8" --lib "$FUEL_ANDROID_JAR" --min-api 26 --output out "${class_files[@]}"
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('out/unsigned.apk','a',zipfile.ZIP_DEFLATED) as apk:
    apk.write('out/classes.dex','classes.dex')
PY
"$FUEL_BUILD_TOOLS/zipalign" -f -p 4 out/unsigned.apk out/aligned.apk
"$FUEL_BUILD_TOOLS/apksigner" sign --ks "$FUEL_SIGNING_KEY" --ks-key-alias harsha-fuel --ks-pass "file:$FUEL_SIGNING_PASSWORD_FILE" --out "$FUEL_APK_OUTPUT" out/aligned.apk
"$FUEL_BUILD_TOOLS/apksigner" verify --verbose "$FUEL_APK_OUTPUT"
"$FUEL_BUILD_TOOLS/aapt2" dump badging "$FUEL_APK_OUTPUT"
