package com.harsha.fuel;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Chrome Custom Tabs container. It shares the existing website's browser storage.
 *  No JavaScript bridge, tracking, file access, camera or microphone permissions.
 */
public final class MainActivity extends Activity {
    private static final String APP_URL = "https://harsha1996acchu-sketch.github.io/Harsha-Fuel/";
    private static final int GREEN = Color.rgb(46, 105, 73);
    private static final int BACKGROUND = Color.rgb(247, 248, 242);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(dp(28), dp(36), dp(28), dp(36));
        layout.setBackgroundColor(BACKGROUND);
        layout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
            layout.setPadding(dp(28), dp(36) + insets.getSystemWindowInsetTop(),
                    dp(28), dp(36) + insets.getSystemWindowInsetBottom());
            return insets;
            }
        });
        TextView mark = text("hf.", 44, GREEN);
        mark.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        layout.addView(mark);
        TextView title = text("Harsha Fuel", 30, Color.rgb(32, 43, 35));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        layout.addView(title);
        layout.addView(text("Your kitchen. Your food companion.", 16, Color.rgb(107,121,110)));
        TextView note = text("Runs with Chrome to keep your on-device Gemma and saved food data.\n\nAdd your food pictures using Edit photo on each card.", 14, Color.rgb(107,121,110));
        note.setPadding(0,dp(26),0,dp(28));
        layout.addView(note);
        Button open = new Button(this);
        open.setText("Open Harsha Fuel");
        open.setTextColor(Color.WHITE);
        open.setAllCaps(false);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(GREEN);
        shape.setCornerRadius(dp(16));
        open.setBackground(shape);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(54));
        layout.addView(open, params);
        open.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openApp(); }
        });
        setContentView(layout);
        // The normal launcher path opens the app immediately; returning from Chrome
        // leaves this explicit launch screen rather than repeatedly reopening it.
        if (state == null) layout.post(new Runnable() {
            @Override public void run() { openApp(); }
        });
    }

    private TextView text(String value, int sp, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, dp(6), 0, dp(6));
        return text;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void openApp() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(APP_URL));
        Bundle extras = new Bundle();
        // A null session binder selects Custom Tabs without a bound browser service.
        extras.putBinder("android.support.customtabs.extra.SESSION", null);
        intent.putExtras(extras);
        intent.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR", BACKGROUND);
        intent.putExtra("android.support.customtabs.extra.NAVIGATION_BAR_COLOR", BACKGROUND);
        intent.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", true);
        intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 0);
        intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 2);
        intent.setPackage("com.android.chrome");
        Bundle animation = ActivityOptions.makeCustomAnimation(this,
                android.R.anim.fade_in, android.R.anim.fade_out).toBundle();
        try { startActivity(intent, animation); }
        catch (ActivityNotFoundException missingChrome) {
            intent.setPackage(null);
            try {
                startActivity(intent, animation);
                Toast.makeText(this, "Use Chrome for the offline Gemma Coach.", Toast.LENGTH_LONG).show();
            } catch (ActivityNotFoundException noBrowser) {
                Toast.makeText(this, "Install Chrome, then open Harsha Fuel again.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
