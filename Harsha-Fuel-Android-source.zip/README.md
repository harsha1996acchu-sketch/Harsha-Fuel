# Harsha Fuel Android 1.0

Chrome Custom Tabs container for https://harsha1996acchu-sketch.github.io/Harsha-Fuel/. Android 8+; targets Android 15 (API 35). Requires Chrome for the supported on-device Gemma flow. The APK may display Chrome’s toolbar and is not an independently bundled web app or native inference engine. Normal Chrome site storage, model and cache remain separate from this launcher. The app requests no Android permissions. All food-photo selection and compression happens in the website after a user gesture.

## Rebuild

Use Android SDK platform 35, Build Tools 35.0.0, Java 17 runtime, Python 3, and Eclipse ECJ 3.38.0 from Maven Central. Set FUEL_ANDROID_JAR, FUEL_BUILD_TOOLS and FUEL_ECJ_JAR to the local installation paths. Set FUEL_SIGNING_KEY and FUEL_SIGNING_PASSWORD_FILE to the existing private signing credential files to produce compatible updates. Signing credentials and SDK binaries are intentionally excluded. Then run `bash build.sh`. The script compiles Java bytecode, converts it to DEX, packages resources, aligns the APK and checks the signature. Set FUEL_APK_OUTPUT to change its destination. Increase versionCode/versionName in AndroidManifest.xml when publishing an updated launcher.

The companion website updates independently through GitHub Pages.
